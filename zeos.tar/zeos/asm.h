#ifndef ASM_H
#define ASM_H

// Declaracio de la funcion asm
int addASM(int a, int b);

#endif
